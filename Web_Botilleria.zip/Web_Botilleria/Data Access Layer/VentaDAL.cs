﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Data_Access_Layer
{
    public class VentaDAL
    {
        //public Boolean GenerarVenta()
        //{
        //    //modificar
        //    //Este metodo tomara los datos que el usuario agrega al carro e imprimira una boleta con los datos, precio, iva, etc.
        //    return true;
        //}
    }
}
