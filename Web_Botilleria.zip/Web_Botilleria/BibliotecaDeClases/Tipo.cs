﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BibliotecaClases
{
    public enum Tipo
    {
        NoExiste = 0,
        Fantasia = 1,
        Jugo = 2,
        Vodka = 3,
        Ron_Dorado = 4,
        Ron_Blanco = 5,
        Vodka_saborizado = 6,
        Pisco = 7,
        Cerveza = 8,
        Pipeño = 9,
        Vino = 10,
        Chicha = 11,
        Tequila = 12,
        Champan = 13,
        Whisky = 14
    }
}
