﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BibliotecaClases
{
    public enum Marca
    {
        No_figura = 0,
        Coca_Cola_Company = 1,
        CCU = 2,
        Fruna = 3,
        Rari = 4,
        Stolichnaya = 5,
        Absolut = 6,
        Smirnoff = 7,
        Ciroc = 8,
        Skyy = 9,
        Wyboriwa = 10
    }
}
